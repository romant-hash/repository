# Powerus systems catalog

Next.js app for the systems catalog browsing tool.

## Run locally
```
npm install
npm run dev
```

## Deploy on Vercel
1. Push this folder as the repo root (or set it as the Vercel project's root directory).
2. Import the repo at vercel.com/new — framework preset: Next.js, no env vars needed.
3. Deploy. Build command `next build`, output handled by Vercel.

The page needs network access: product photography loads from power.us and three.js
loads from unpkg.

## What's here
- `app/` — Next App Router shell.
- `public/catalog.html` — the self-contained prototype, served full-bleed by `app/page.jsx`.
- `public/drone-viewer.js` — three.js schematic model viewer web component.
- `PORTING.md` — step-by-step plan to replace the frame with real components.
