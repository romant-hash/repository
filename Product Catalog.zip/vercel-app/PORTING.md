# Porting plan — Powerus systems catalog

The deployed app currently serves the prototype (`public/catalog.html`) full-bleed so the
repo builds and deploys from commit one. Replace it with real components in this order.

## 1. Extract the data
Everything is hard-coded in the prototype's logic class. Lift it verbatim into
`lib/systems.js`:

- `SYSTEMS` — the nine systems: id, name, code, class, mission, blurb, status, tile photo.
- `PRODUCT_MODELS[systemId]` — per-model: label, name, photo, fieldPhoto, blurb,
  `specs: [label, value, unit][]`, capHead, `caps: [title, body, chips[]][]`,
  fieldEyebrow, fieldHead, fieldBody, `stats: [value, label][]`.
- `PROC[systemId]` — [procurement note, Blue UAS wording].
- `CERT_SETS[systemId]` — which compliance chips that system publishes.
- `SERIAL_PREFIX[modelId]` — serial placeholder prefixes.

Figures came from the live power.us pages. Reach, Firebreak and Harvest publish none:
their values read "On request" and must not be estimated.

## 2. Components
```
app/page.jsx              shell: header + view toggle, holds view state
components/GridView       auto-fit minmax(288px,1fr) card grid
components/SystemList     268px left rail, 50px square thumbnails
components/ProductPage    sticky header, model nav, tabs
components/SpecsTab       hero + cert chips + spec rows + capabilities + field record + procurement
components/ManualTab      serial-gated document rows
components/HowToTab       open procedure rows
components/VerifyModal    serial + access code
components/DocViewer      Bone page document view
components/BriefModal     inquiry form
components/DroneViewer    client-only wrapper around public/drone-viewer.js
```

## 3. Styling
The prototype is 100% inline styles against the tokens listed in the handoff README.
Either keep inline styles (fastest, exact) or move them to CSS modules with a token file.
Do not introduce a UI framework — the brand system is square corners, hairlines, two
surfaces and one accent.

## 4. Real integrations to replace prototype stubs
- **Brief form** — currently client-side only. POST to the program-desk endpoint/CRM.
- **Document gate** — any serial unlocks. Needs real serial validation and signed URLs for
  the manual PDFs; rows should link to those instead of the placeholder viewer.
- **Photography** — loads from power.us at runtime. Move into the app's asset pipeline.
- **3D models** — schematic geometry built in code. Swap for real OBJ/GLB when available;
  `drone-viewer.js` already auto-frames whatever object it is given.
