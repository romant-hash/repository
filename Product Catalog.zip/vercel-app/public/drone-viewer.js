// <drone-viewer kind="…"> — draggable schematic 3D views of the Powerus systems.
// Classic script; three.js is imported lazily from a pinned CDN build.
(function () {
  if (window.customElements.get('drone-viewer')) return;
  const THREE_URL = 'https://unpkg.com/three@0.160.0/build/three.module.js';
  let threePromise = null;
  const loadThree = () => (threePromise = threePromise || import(THREE_URL));

  class DroneViewer extends HTMLElement {
    connectedCallback() {
      if (this._init) return;
      this._init = true;
      Object.assign(this.style, { display: 'block', position: 'absolute', inset: '0', background: '#101010' });
      this._hint = document.createElement('div');
      this._hint.textContent = 'DRAG TO ORBIT · SCROLL TO ZOOM';
      Object.assign(this._hint.style, {
        position: 'absolute', left: '14px', bottom: '12px', color: '#7C7C7C',
        font: "400 8px/1 'JetBrains Mono',monospace", letterSpacing: '.18em', pointerEvents: 'none', zIndex: '2'
      });
      this.appendChild(this._hint);
      this._label = document.createElement('div');
      Object.assign(this._label.style, {
        position: 'absolute', left: '14px', top: '12px', color: '#9A9A9A',
        font: "400 8px/1 'JetBrains Mono',monospace", letterSpacing: '.18em', pointerEvents: 'none', zIndex: '2'
      });
      this._label.textContent = (this.getAttribute('label') || '').toUpperCase();
      this.appendChild(this._label);
      loadThree().then(T => this._build(T)).catch(() => { this._hint.textContent = '3D VIEW UNAVAILABLE OFFLINE'; });
    }

    static get observedAttributes() { return ['kind', 'label']; }
    attributeChangedCallback(n, o, v) {
      if (!this._scene || o === v) return;
      if (n === 'label' && this._label) this._label.textContent = (v || '').toUpperCase();
      if (n === 'kind') this._swap();
    }

    disconnectedCallback() {
      cancelAnimationFrame(this._raf);
      if (this._ro) this._ro.disconnect();
      if (this._renderer) this._renderer.dispose();
    }

    // ---------- materials ----------
    _mats(T) {
      return {
        shell: new T.MeshStandardMaterial({ color: 0x2c2c2c, metalness: 0.45, roughness: 0.6 }),
        light: new T.MeshStandardMaterial({ color: 0xcfcfcf, metalness: 0.6, roughness: 0.4 }),
        dark: new T.MeshStandardMaterial({ color: 0x151515, metalness: 0.35, roughness: 0.75 }),
        glass: new T.MeshStandardMaterial({ color: 0x1b2a33, metalness: 0.8, roughness: 0.2 }),
        lens: new T.MeshStandardMaterial({ color: 0xff3b16, emissive: 0xff3b16, emissiveIntensity: 0.7, roughness: 0.3 }),
        hull: new T.MeshStandardMaterial({ color: 0x35404a, metalness: 0.4, roughness: 0.6 })
      };
    }

    // ---------- shared parts ----------
    _rotorRing(T, m, x, z, r, spin) {
      const g = new T.Group();
      const motor = new T.Mesh(new T.CylinderGeometry(0.16, 0.19, 0.28, 20), m.dark);
      motor.position.y = 0.2;
      g.add(motor);
      const blades = new T.Group();
      for (let b = 0; b < 2; b++) {
        const bl = new T.Mesh(new T.BoxGeometry(r * 1.9, 0.03, 0.16), m.shell);
        bl.rotation.y = (b * Math.PI) / 2;
        blades.add(bl);
      }
      blades.position.y = 0.38;
      g.add(blades);
      spin.push(blades);
      const ring = new T.Mesh(new T.TorusGeometry(r, 0.016, 8, 44), m.light);
      ring.rotation.x = Math.PI / 2;
      ring.position.y = 0.38;
      g.add(ring);
      g.position.set(x, 0, z);
      return g;
    }

    _multirotor(T, m, spin, opt) {
      const { arms = 4, reach = 1.6, rotor = 0.78, bodyW = 2, bodyH = 0.55, bodyD = 1.2, skids = true } = opt;
      const g = new T.Group();
      const body = new T.Mesh(new T.BoxGeometry(bodyW, bodyH, bodyD), m.shell);
      g.add(body);
      const spine = new T.Mesh(new T.BoxGeometry(bodyW * 1.05, 0.08, bodyD * 0.34), m.light);
      spine.position.y = bodyH / 2 + 0.05;
      g.add(spine);
      for (let i = 0; i < arms; i++) {
        const a = (i / arms) * Math.PI * 2 + Math.PI / arms;
        const x = Math.cos(a) * reach, z = Math.sin(a) * reach;
        const arm = new T.Mesh(new T.BoxGeometry(reach, 0.12, 0.18), m.light);
        arm.position.set(x / 2, 0.06, z / 2);
        arm.rotation.y = -a;
        g.add(arm);
        g.add(this._rotorRing(T, m, x, z, rotor, spin));
      }
      if (skids) {
        [-bodyD * 0.45, bodyD * 0.45].forEach(z => {
          const skid = new T.Mesh(new T.BoxGeometry(bodyW * 0.75, 0.06, 0.06), m.light);
          skid.position.set(0, -bodyH / 2 - 0.55, z);
          g.add(skid);
          [-bodyW * 0.25, bodyW * 0.25].forEach(x => {
            const leg = new T.Mesh(new T.BoxGeometry(0.06, 0.55, 0.06), m.light);
            leg.position.set(x, -bodyH / 2 - 0.28, z);
            g.add(leg);
          });
        });
      }
      return g;
    }

    _sensorBall(T, m, pos, r) {
      const g = new T.Group();
      const ball = new T.Mesh(new T.SphereGeometry(r, 26, 18), m.dark);
      g.add(ball);
      const eye = new T.Mesh(new T.CylinderGeometry(r * 0.42, r * 0.42, 0.07, 20), m.lens);
      eye.rotation.z = Math.PI / 2;
      eye.position.x = r * 0.92;
      g.add(eye);
      g.position.set(pos[0], pos[1], pos[2]);
      return g;
    }

    // ---------- per-product builders ----------
    _build3(T, m, spin) { // Matrix 3 — micro quad with prop guards
      const g = this._multirotor(T, m, spin, { arms: 4, reach: 1.0, rotor: 0.5, bodyW: 1.1, bodyH: 0.4, bodyD: 0.8, skids: false });
      g.add(this._sensorBall(T, m, [0.62, -0.16, 0], 0.2));
      for (let i = 0; i < 4; i++) {
        const a = (i / 4) * Math.PI * 2 + Math.PI / 4;
        const cage = new T.Mesh(new T.TorusGeometry(0.54, 0.03, 8, 40), m.shell);
        cage.rotation.x = Math.PI / 2;
        cage.position.set(Math.cos(a), 0.44, Math.sin(a));
        g.add(cage);
      }
      return g;
    }
    _build5(T, m, spin) { // Matrix 5 — ultralight quad
      const g = this._multirotor(T, m, spin, { arms: 4, reach: 1.45, rotor: 0.7, bodyW: 1.6, bodyH: 0.46, bodyD: 1.0 });
      g.add(this._sensorBall(T, m, [0.72, -0.22, 0], 0.26));
      const batt = new T.Mesh(new T.BoxGeometry(0.8, 0.22, 0.6), m.dark);
      batt.position.set(-0.25, 0.4, 0);
      g.add(batt);
      return g;
    }
    _build7(T, m, spin) { // Matrix 7 — payload quad, fixed sensor mount
      const g = this._multirotor(T, m, spin, { arms: 4, reach: 1.7, rotor: 0.82, bodyW: 2.1, bodyH: 0.58, bodyD: 1.25 });
      const mount = new T.Mesh(new T.BoxGeometry(0.5, 0.34, 0.5), m.dark);
      mount.position.set(0.6, -0.5, 0);
      g.add(mount);
      g.add(this._sensorBall(T, m, [0.78, -0.72, 0], 0.3));
      const pack = new T.Mesh(new T.BoxGeometry(1.0, 0.26, 0.7), m.dark);
      pack.position.set(-0.3, 0.44, 0);
      g.add(pack);
      return g;
    }
    _build10(T, m, spin) { // Matrix 10 — extended range, larger airframe
      const g = this._multirotor(T, m, spin, { arms: 4, reach: 2.2, rotor: 1.05, bodyW: 2.6, bodyH: 0.66, bodyD: 1.5 });
      g.add(this._sensorBall(T, m, [0.95, -0.82, 0], 0.34));
      const bay = new T.Mesh(new T.BoxGeometry(1.3, 0.4, 0.9), m.dark);
      bay.position.set(-0.2, -0.6, 0);
      g.add(bay);
      [-1, 1].forEach(s => {
        const ant = new T.Mesh(new T.CylinderGeometry(0.03, 0.03, 1.1, 10), m.light);
        ant.position.set(-1.1, 0.55, s * 0.4);
        g.add(ant);
      });
      return g;
    }
    _buildFold(T, m, spin) { // Matrix Fold — folding hybrid with cartridge bay
      const g = this._multirotor(T, m, spin, { arms: 6, reach: 1.65, rotor: 0.72, bodyW: 1.7, bodyH: 0.6, bodyD: 1.15 });
      const cart = new T.Mesh(new T.BoxGeometry(0.95, 0.42, 0.78), m.dark);
      cart.position.set(-0.15, -0.62, 0);
      g.add(cart);
      const rails = new T.Mesh(new T.BoxGeometry(1.05, 0.05, 0.86), m.light);
      rails.position.set(-0.15, -0.38, 0);
      g.add(rails);
      const gim = new T.Group();
      gim.add(this._sensorBall(T, m, [0, 0, 0], 0.3));
      const yoke = new T.Mesh(new T.TorusGeometry(0.36, 0.028, 8, 32), m.light);
      gim.add(yoke);
      gim.position.set(0.75, -0.62, 0);
      g.add(gim);
      return g;
    }
    _buildT(T, m, spin) { // Matrix T — trainer, high-visibility bands
      const g = this._multirotor(T, m, spin, { arms: 4, reach: 1.7, rotor: 0.8, bodyW: 2.0, bodyH: 0.56, bodyD: 1.2 });
      const band = new T.MeshStandardMaterial({ color: 0xff6200, roughness: 0.5 });
      [-1, 1].forEach(s => {
        const b = new T.Mesh(new T.BoxGeometry(0.16, 0.6, 1.26), band);
        b.position.set(s * 0.7, 0, 0);
        g.add(b);
      });
      g.add(this._sensorBall(T, m, [0.72, -0.4, 0], 0.24));
      return g;
    }
    _buildKit(T, m) { // Matrix Pilot Kit — ground station case
      const g = new T.Group();
      const shellCase = new T.Mesh(new T.BoxGeometry(3.4, 0.5, 2.3), m.shell);
      g.add(shellCase);
      const lid = new T.Mesh(new T.BoxGeometry(3.4, 2.0, 0.16), m.shell);
      lid.position.set(0, 1.0, -1.05);
      lid.rotation.x = -0.18;
      g.add(lid);
      const screen = new T.Mesh(new T.BoxGeometry(2.9, 1.6, 0.05), m.glass);
      screen.position.set(0, 1.0, -0.94);
      screen.rotation.x = -0.18;
      g.add(screen);
      [-0.9, 0.9].forEach(x => {
        const stick = new T.Mesh(new T.CylinderGeometry(0.08, 0.1, 0.34, 14), m.dark);
        stick.position.set(x, 0.42, 0.55);
        g.add(stick);
        const knob = new T.Mesh(new T.SphereGeometry(0.13, 16, 12), m.light);
        knob.position.set(x, 0.62, 0.55);
        g.add(knob);
      });
      for (let i = 0; i < 6; i++) {
        const key = new T.Mesh(new T.BoxGeometry(0.2, 0.08, 0.2), m.dark);
        key.position.set(-0.45 + (i % 3) * 0.45, 0.3, 0.35 + Math.floor(i / 3) * 0.32);
        g.add(key);
      }
      [-1.3, 1.3].forEach(x => {
        const ant = new T.Mesh(new T.CylinderGeometry(0.035, 0.035, 1.5, 10), m.light);
        ant.position.set(x, 1.0, -0.6);
        ant.rotation.z = x > 0 ? -0.18 : 0.18;
        g.add(ant);
      });
      const led = new T.Mesh(new T.SphereGeometry(0.07, 12, 10), m.lens);
      led.position.set(1.4, 0.3, 0.9);
      g.add(led);
      return g;
    }
    _buildGuardian(T, m, spin) { // Guardian — interceptor
      const g = new T.Group();
      const fus = new T.Mesh(new T.CylinderGeometry(0.3, 0.24, 2.6, 22), m.shell);
      fus.rotation.z = Math.PI / 2;
      g.add(fus);
      const nose = new T.Mesh(new T.ConeGeometry(0.3, 0.85, 22), m.dark);
      nose.rotation.z = -Math.PI / 2;
      nose.position.x = 1.7;
      g.add(nose);
      const seeker = new T.Mesh(new T.SphereGeometry(0.16, 18, 14), m.lens);
      seeker.position.x = 2.14;
      g.add(seeker);
      for (let i = 0; i < 4; i++) {
        const a = (i / 4) * Math.PI * 2 + Math.PI / 4;
        const x = Math.cos(a) * 1.15, z = Math.sin(a) * 1.15;
        const arm = new T.Mesh(new T.BoxGeometry(1.2, 0.1, 0.14), m.light);
        arm.position.set(x / 2, 0.02, z / 2);
        arm.rotation.y = -a;
        g.add(arm);
        g.add(this._rotorRing(T, m, x, z, 0.62, spin));
      }
      [[0, 1], [0, -1], [1, 0]].forEach(([fy, fz]) => {
        const fin = new T.Mesh(new T.BoxGeometry(0.6, fy ? 0.5 : 0.05, fz ? 0.5 : 0.05), m.light);
        fin.position.set(-1.25, fy * 0.3, fz * 0.3);
        g.add(fin);
      });
      return g;
    }
    _buildDragon(T, m, spin) { // Dragon — heavy-lift with slung load
      const g = this._multirotor(T, m, spin, { arms: 8, reach: 2.6, rotor: 1.05, bodyW: 2.6, bodyH: 0.8, bodyD: 2.0, skids: false });
      const cargo = new T.Mesh(new T.BoxGeometry(2.0, 1.1, 1.5), m.dark);
      cargo.position.y = -1.5;
      g.add(cargo);
      [[-0.8, -0.6], [0.8, -0.6], [-0.8, 0.6], [0.8, 0.6]].forEach(([x, z]) => {
        const line = new T.Mesh(new T.CylinderGeometry(0.025, 0.025, 0.85, 8), m.light);
        line.position.set(x * 0.6, -0.85, z * 0.6);
        g.add(line);
        const leg = new T.Mesh(new T.BoxGeometry(0.08, 1.0, 0.08), m.light);
        leg.position.set(x * 1.1, -0.55, z * 1.1);
        g.add(leg);
      });
      return g;
    }
    _buildSpy(T, m, spin) { // xFold Spy — folding hexa, gimballed EO/IR
      const g = this._multirotor(T, m, spin, { arms: 6, reach: 1.9, rotor: 0.8, bodyW: 1.5, bodyH: 0.62, bodyD: 1.1 });
      const gim = new T.Group();
      gim.add(this._sensorBall(T, m, [0, 0, 0], 0.34));
      const yoke = new T.Mesh(new T.TorusGeometry(0.42, 0.03, 8, 32), m.light);
      gim.add(yoke);
      gim.position.set(0.5, -0.72, 0);
      g.add(gim);
      const rail = new T.Mesh(new T.BoxGeometry(1.4, 0.07, 0.14), m.light);
      rail.position.set(0, -0.42, 0);
      g.add(rail);
      return g;
    }
    _buildReach(T, m, spin) { // Reach — mothership loiter
      const g = this._multirotor(T, m, spin, { arms: 4, reach: 2.4, rotor: 1.1, bodyW: 3.0, bodyH: 0.7, bodyD: 1.6 });
      const bay = new T.Mesh(new T.BoxGeometry(1.6, 0.5, 1.1), m.dark);
      bay.position.set(0, -0.7, 0);
      g.add(bay);
      const child = this._multirotor(T, m, spin, { arms: 4, reach: 0.6, rotor: 0.28, bodyW: 0.6, bodyH: 0.2, bodyD: 0.4, skids: false });
      child.scale.setScalar(0.72);
      child.position.set(0, -1.25, 0);
      g.add(child);
      return g;
    }
    _buildBlueSky(T, m) { // Blue Sky — autonomous surface vessel retrofit
      const g = new T.Group();
      const hull = new T.Mesh(new T.CylinderGeometry(0.75, 0.75, 4.4, 20, 1, false, 0, Math.PI), m.hull);
      hull.rotation.z = Math.PI / 2;
      hull.rotation.y = Math.PI;
      g.add(hull);
      const bow = new T.Mesh(new T.ConeGeometry(0.75, 1.5, 20, 1, false, 0, Math.PI), m.hull);
      bow.rotation.z = -Math.PI / 2;
      bow.rotation.y = Math.PI;
      bow.position.x = 2.9;
      g.add(bow);
      const deck = new T.Mesh(new T.BoxGeometry(5.6, 0.1, 1.5), m.light);
      deck.position.y = 0.02;
      g.add(deck);
      const house = new T.Mesh(new T.BoxGeometry(1.5, 0.8, 1.1), m.shell);
      house.position.set(-0.2, 0.45, 0);
      g.add(house);
      const mast = new T.Mesh(new T.CylinderGeometry(0.06, 0.06, 1.6, 12), m.light);
      mast.position.set(-0.2, 1.65, 0);
      g.add(mast);
      const radar = new T.Mesh(new T.BoxGeometry(1.0, 0.12, 0.12), m.light);
      radar.position.set(-0.2, 2.4, 0);
      g.add(radar);
      g.add(this._sensorBall(T, m, [0.6, 1.0, 0], 0.22));
      const water = new T.Mesh(new T.PlaneGeometry(14, 14), new T.MeshStandardMaterial({ color: 0x14202a, roughness: 0.25, metalness: 0.6, transparent: true, opacity: 0.85 }));
      water.rotation.x = -Math.PI / 2;
      water.position.y = -0.25;
      g.add(water);
      return g;
    }
    _buildTank(T, m, spin, agri) { // Firebreak / Harvest — heavy-lift with tank
      const g = this._multirotor(T, m, spin, { arms: 6, reach: 2.4, rotor: 1.0, bodyW: 2.2, bodyH: 0.7, bodyD: 1.6, skids: true });
      const tank = new T.Mesh(new T.CylinderGeometry(0.72, 0.72, 1.7, 22), agri ? m.light : m.dark);
      tank.rotation.z = Math.PI / 2;
      tank.position.y = -0.85;
      g.add(tank);
      if (agri) {
        [-1, 1].forEach(s => {
          const boom = new T.Mesh(new T.BoxGeometry(0.06, 0.06, 2.6), m.light);
          boom.position.set(s * 0.9, -1.3, 0);
          g.add(boom);
          for (let i = -2; i <= 2; i++) {
            const noz = new T.Mesh(new T.ConeGeometry(0.07, 0.16, 10), m.dark);
            noz.position.set(s * 0.9, -1.42, i * 0.55);
            g.add(noz);
          }
        });
      } else {
        const nozzle = new T.Mesh(new T.ConeGeometry(0.24, 0.5, 16), m.lens);
        nozzle.rotation.x = Math.PI;
        nozzle.position.set(0.9, -1.15, 0);
        g.add(nozzle);
      }
      return g;
    }
    _buildXnav(T, m) { // xNav AI — autonomy core, no airframe
      const g = new T.Group();
      const core = new T.Mesh(new T.IcosahedronGeometry(1.05, 1), new T.MeshStandardMaterial({ color: 0x1d1d1d, metalness: 0.5, roughness: 0.45, flatShading: true }));
      g.add(core);
      const wire = new T.Mesh(new T.IcosahedronGeometry(1.35, 1), new T.MeshBasicMaterial({ color: 0x8f8f8f, wireframe: true, transparent: true, opacity: 0.55 }));
      g.add(wire);
      this._spinSlow = wire;
      [0, 1, 2].forEach(i => {
        const ring = new T.Mesh(new T.TorusGeometry(1.85 + i * 0.28, 0.012, 8, 80), m.light);
        ring.rotation.x = Math.PI / 2 + i * 0.5;
        ring.rotation.z = i * 0.7;
        g.add(ring);
      });
      const node = new T.Mesh(new T.SphereGeometry(0.1, 14, 12), m.lens);
      node.position.set(1.85, 0, 0);
      g.add(node);
      return g;
    }

    _make(T, kind) {
      const m = this._mats(T);
      const spin = [];
      this._rotors = spin;
      this._spinSlow = null;
      let g;
      switch (kind) {
        case 'matrix-3': g = this._build3(T, m, spin); break;
        case 'matrix-5': g = this._build5(T, m, spin); break;
        case 'matrix-10': g = this._build10(T, m, spin); break;
        case 'matrix-fold': g = this._buildFold(T, m, spin); break;
        case 'matrix-t': g = this._buildT(T, m, spin); break;
        case 'matrix-kit': g = this._buildKit(T, m); break;
        case 'guardian': g = this._buildGuardian(T, m, spin); break;
        case 'dragon': g = this._buildDragon(T, m, spin); break;
        case 'spy': g = this._buildSpy(T, m, spin); break;
        case 'reach': g = this._buildReach(T, m, spin); break;
        case 'bluesky': g = this._buildBlueSky(T, m); break;
        case 'firebreak': g = this._buildTank(T, m, spin, false); break;
        case 'harvest': g = this._buildTank(T, m, spin, true); break;
        case 'xnav': g = this._buildXnav(T, m); break;
        default: g = this._build7(T, m, spin);
      }
      g.name = kind || 'matrix-7';
      return g;
    }

    _frame() {
      const T = this._T, box = new T.Box3().setFromObject(this._obj);
      const size = box.getSize(new T.Vector3());
      const center = box.getCenter(new T.Vector3());
      this._obj.position.sub(center);
      this._dist = Math.max(size.x, size.y, size.z) * 2.05 + 1.2;
      this._minD = this._dist * 0.45;
      this._maxD = this._dist * 2.1;
    }

    _swap() {
      if (!this._scene) return;
      this._scene.remove(this._obj);
      this._obj = this._make(this._T, this.getAttribute('kind'));
      this._scene.add(this._obj);
      this._frame();
    }

    _build(T) {
      this._T = T;
      const scene = new T.Scene();
      this._scene = scene;
      const camera = new T.PerspectiveCamera(32, 1, 0.1, 400);
      const renderer = new T.WebGLRenderer({ antialias: true, alpha: true });
      renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
      Object.assign(renderer.domElement.style, { display: 'block', cursor: 'grab', width: '100%', height: '100%' });
      this.appendChild(renderer.domElement);
      this._renderer = renderer;

      this._obj = this._make(T, this.getAttribute('kind'));
      scene.add(this._obj);
      this._frame();

      scene.add(new T.HemisphereLight(0xffffff, 0x0d0d0d, 0.9));
      const key = new T.DirectionalLight(0xffffff, 1.45);
      key.position.set(5, 7, 4);
      scene.add(key);
      const rim = new T.DirectionalLight(0x9ecbff, 0.55);
      rim.position.set(-6, 2, -5);
      scene.add(rim);

      let az = 0.75, pol = 1.12, dragging = false, px = 0, py = 0, idle = 0;
      const el = renderer.domElement;
      el.addEventListener('pointerdown', e => { dragging = true; px = e.clientX; py = e.clientY; idle = 0; el.style.cursor = 'grabbing'; el.setPointerCapture(e.pointerId); });
      el.addEventListener('pointermove', e => {
        if (!dragging) return;
        az -= (e.clientX - px) * 0.008;
        pol = Math.min(Math.PI - 0.22, Math.max(0.22, pol - (e.clientY - py) * 0.006));
        px = e.clientX; py = e.clientY; idle = 0;
      });
      const stop = e => { dragging = false; el.style.cursor = 'grab'; if (e && e.pointerId != null && el.hasPointerCapture(e.pointerId)) el.releasePointerCapture(e.pointerId); };
      el.addEventListener('pointerup', stop);
      el.addEventListener('pointercancel', stop);
      el.addEventListener('wheel', e => { e.preventDefault(); this._dist = Math.min(this._maxD, Math.max(this._minD, this._dist + e.deltaY * 0.01)); idle = 0; }, { passive: false });

      let lastW = 0, lastH = 0;
      const size = () => {
        const r = this.getBoundingClientRect();
        if (Math.abs(r.width - lastW) < 1 && Math.abs(r.height - lastH) < 1) return;
        lastW = r.width; lastH = r.height;
        const w = Math.max(160, Math.min(2400, Math.round(r.width) || 640));
        const h = Math.max(120, Math.min(1600, Math.round(r.height) || 360));
        renderer.setSize(w, h, false);
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
      };
      this._ro = new ResizeObserver(size);
      this._ro.observe(this);
      size();

      const tick = () => {
        this._raf = requestAnimationFrame(tick);
        idle += 1;
        if (idle % 20 === 0) size();
        if (!dragging && idle > 110) az += 0.0022;
        (this._rotors || []).forEach(g => { g.rotation.y += 0.16; });
        if (this._spinSlow) { this._spinSlow.rotation.y += 0.004; this._spinSlow.rotation.x += 0.002; }
        camera.position.set(
          this._dist * Math.sin(pol) * Math.cos(az),
          this._dist * Math.cos(pol),
          this._dist * Math.sin(pol) * Math.sin(az)
        );
        camera.lookAt(0, 0, 0);
        renderer.render(scene, camera);
      };
      tick();
    }
  }
  window.customElements.define('drone-viewer', DroneViewer);
})();
