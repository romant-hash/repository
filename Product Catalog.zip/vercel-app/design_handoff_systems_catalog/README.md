# Handoff: Powerus Systems Catalog (option 1a)

## Overview
A standalone product-catalog browsing tool for the nine Powerus systems. Two views: a
grid of all systems, and a two-pane browser (system list left, product page right) with a
model/variant layer, Specs / Tech manual / How-to tabs, a serial-gated document set, a
3D model viewer and a "Request a brief" inquiry form.

## About the design files
The files in this bundle are **design references created in HTML** — a working prototype
of the intended look and behavior, not production code to copy. The task is to recreate
these designs in the target codebase (React/Next on Vercel is the assumed target) using
its own patterns, then wire the data to a real source. If no codebase exists yet, Next.js
App Router + plain CSS modules is the closest fit to how the prototype is written.

## Fidelity
**High fidelity.** Colors, type, spacing and interaction states are final and taken from the
Powerus Brand Operating System v2.0. Recreate pixel-accurately.

## Files in this bundle
- `Systems Catalog Live.dc.html` — the fluid, responsive build (the one to port). Design
  Component format: markup at the top, logic class in the `<script type="text/x-dc">` block.
- `powerus-systems-catalog-live.html` — the same page inlined into one self-contained file.
  Open it in a browser to see the finished behavior. Deployable as-is to any static host.
- `drone-viewer.js` — `<drone-viewer kind label>` web component: three.js schematic model
  per system, pointer-drag orbit, wheel zoom, idle auto-rotate, auto-framed camera.
  three.js is imported lazily from `unpkg.com/three@0.160.0`.
- `assets/` — Powerus monogram, US flag cert glyph, and the two user-supplied photos
  (Matrix Pilot Kit, Blue Sky Horizon).

## Screens

### 1. Header (both views)
Sticky at card top. Powerus monogram (`assets/logo/icon-light.svg`, 28x28) left; view
toggle right: two icon-only buttons in a 1px `rgba(255,255,255,.28)` outlined group —
Split (first, active by default) and Grid. Active button: `#FFFFFF` fill, `#0E0E0E` icon.
Inactive: transparent fill, `#9A9A9A` icon. 13px margin top, 13px padding bottom, hairline
`rgba(255,255,255,.16)` underneath.

### 2. Grid view
`display:grid; grid-template-columns:repeat(auto-fit,minmax(288px,1fr)); gap:clamp(24px,3vw,34px) clamp(18px,2vw,26px)`.
Each card: 16:9 photo, name (Manrope 400, clamp(24px,2.6vw,34px), -.04em) with status in
mono 9.5px `.16em` beside it, 12px/1.5 blurb, then four spec rows (mono label 9.5px
`#B4B4B4` left, value 11px right, 1px top hairline each), then two buttons: "Request a brief"
(white fill, `#0E0E0E` text) and "System details" (transparent, `rgba(255,255,255,.32)` border).
Photo, name and blurb are click targets that open the product page — nothing links off-site.

### 3. Split view
`grid-template-columns:minmax(0,268px) minmax(0,1fr)`, both columns `overflow-y:auto`,
1px divider between.

**Left list** — one row per system: 50x50 square thumbnail (object-fit cover), name
(Manrope 17px, -.035em), class in mono 8.5px `#7C7C7C`. Selected row: `#1E1E1E` background,
2px `#FFFFFF` left border, full-opacity thumbnail; unselected thumbnails at 0.62 opacity.

**Right pane** — sticky header (`top:-1px`, `#1B1B1B`, `box-shadow:0 -2px 0 0 #1B1B1B`)
containing the `[ DESCRIPTOR ]` eyebrow (mono 9.5px, `.2em`, `#9A9A9A`), the model name
(Manrope clamp(28px,3.8vw,40px)/0.96, -.05em) and the Request a brief button. On scroll
past 10px the eyebrow collapses (max-height 24px to 0 over .3s linear, opacity over .22s)
and header padding goes 16px to 11px on the same curve.

Below it: the model nav (only when a system has 2+ models) as outlined chips on `#1B1B1B`,
active chip white-filled; then the tab row (Specs / Tech manual / How-to, mono 10px,
active white with a 2px underline).

**Specs tab** — hero (16:9) with a 3D toggle bottom-right; cert chips row (pill, 1px
`rgba(255,255,255,.22)`, mono 8px) beside the blurb in a `minmax(0,1.5fr) minmax(0,1fr)`
grid whose right column holds the spec rows; capabilities grid
(`repeat(auto-fit,minmax(248px,1fr))`, hairline-separated cards: 17px title, 11.5px body,
pill chips); field-record block (eyebrow, clamp(24px,3.2vw,32px) headline, 12px body,
three oversized stats at clamp(30px,3.8vw,40px)) followed by its photo flush to the stats
hairline; procurement note plus a six-cell table (CAGE, manufacturing, compliance,
Blue UAS, capacity, lead time).

**Tech manual tab** — numbered document rows. Locked state: lock glyph, gray title,
"LOCKED" in place of "PDF"; clicking a row opens the verify modal (serial number with a
model-derived placeholder e.g. MTX7-0000-0000, access code, inline error if either is
empty, Verify and Request access). After verify: "Verified · [serial]" bar with a Lock
action, rows show PDF and open a document viewer — dark toolbar (Back, Download PDF)
over a Bone `#FDFAF3` page with title, "REV C · [serial]" and a controlled-document footer.

**How-to tab** — same row layout, never gated, meta column shows durations.

### 4. Request a brief modal
Full-bleed over the tool. Fields: first name*, last name*, email*, phone* in a
`repeat(auto-fit,minmax(min(100%,300px),1fr))` grid capped at 900px, then company name,
inquiry type (select), subject* (prefilled "[Model] — request a brief", uncontrolled so it
stays editable) and message*. Underline inputs: transparent background, 1px `#FFFFFF`
bottom border, Manrope 14px. Required asterisks in Ember `#FF6200`. Submit swaps to an
"Inquiry received" confirmation.

### 5. 3D viewer
Toggling the hero swaps the photo for `<drone-viewer>`; the same button position returns
to the photo (cube icon out, image icon back, both icon-only). Fourteen distinct schematic
builds keyed by model id; camera auto-frames each one.

## Interactions
- View toggle: split (default) / grid.
- Grid card photo, name, blurb, and System details → open that system's product page.
- Grid card Request a brief → modal with that system in the subject.
- Model nav → swaps all product content and the 3D model kind; resets hero to photo.
- Tabs → Specs / Tech manual / How-to.
- Tech manual row → verify modal (locked) or document viewer (unlocked).
- All transitions linear; no easing flourishes, no scale or glow on hover (brand rule).

## State
`pane` ("split" | "grid"), `detId` (system), `model` (variant id), `tab`
("specs" | "manual" | "howto"), `hero` ("photo" | "3d"), `scrolled` (bool, drives the
header collapse), `brief` (null | "form" | "sent"), `briefFor` (subject override from a
grid card), `docAccess` (verified serial string | null), `codeOpen`, `codeError`,
`viewerDoc` (document title | null).

## Design tokens
- Surfaces: `#161616` page, `#0E0E0E` panes and overlays, `#1B1B1B` header and banners,
  `#1E1E1E` selected row, `#242424` image wells, `#FDFAF3` Bone document page.
- Ink: `#FFFFFF` primary, `#B4B4B4` secondary, `#9A9A9A` labels, `#7C7C7C` tertiary.
- Accent: Ember `#FF6200` — required-field asterisks and validation only, under 5% of surface.
- Hairlines: `rgba(255,255,255,.1)` internal, `rgba(255,255,255,.16)` section, `rgba(255,255,255,.22–.32)` borders.
- Type: Manrope 400 for display and body; JetBrains Mono for all labels, values and
  eyebrows, uppercase, letter-spacing .14–.2em. Mono sizes 8–11px, body 11.5–14px,
  headlines clamp() as listed above.
- Radius: 0 everywhere except 999px pills (chips only).
- No shadows except the 1px header background shim.

## Assets
- `assets/logo/icon-light.svg` — Powerus monogram, from the Powerus design system.
- `assets/cert/us-flag.png` — design-system cert glyph (currently drawn inline as SVG in
  the page; the PNG is included for reference).
- `assets/photo/matrix-pilot-kit-hero.png`, `assets/photo/blue-sky-horizon-hero.png` —
  supplied by the client.
- All other product photography loads from `https://www.power.us/assets/products/...` at
  runtime. For production, move these into the app's own asset pipeline.

## Data
All content is hard-coded in the logic class and was transcribed from the live power.us
system pages (Matrix, Guardian, Dragon, Spy, Blue Sky, xNav). `PRODUCT_MODELS` /
`MATRIX_MODELS` hold per-model blurb, specs, capabilities, field record and stats;
`PROC` holds procurement copy; `CERT_SETS` holds per-system compliance chips;
`SERIAL_PREFIX` holds serial placeholders. Port this to a CMS or JSON API — the shape
maps 1:1 to the arrays as written. Reach, Firebreak and Harvest have no published figures;
their spec values read "On request" and must not be filled with estimates.

## Deploying
`powerus-systems-catalog-live.html` is a complete static page. On Vercel, drop it in
`public/` (or as `index.html` in a static project) and deploy — no build step. It needs
network access for power.us photos and the three.js CDN.
