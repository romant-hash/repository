export const metadata = {
  title: 'Powerus — systems catalog',
  description: 'Browse and specify the Powerus autonomous systems lineup.'
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500&family=JetBrains+Mono:wght@400&display=swap"
          rel="stylesheet"
        />
      </head>
      <body style={{ margin: 0, background: '#161616', color: '#FFFFFF', fontFamily: 'Manrope, system-ui, sans-serif', WebkitFontSmoothing: 'antialiased' }}>
        {children}
      </body>
    </html>
  );
}
