'use client';

// The catalog prototype ships as a single self-contained document in /public.
// It is served full-bleed here so the app deploys and runs immediately.
// Port target: replace this frame with real components — see ../PORTING.md
// and design_handoff_systems_catalog/README.md for the full spec.
export default function Page() {
  return (
    <main style={{ position: 'fixed', inset: 0 }}>
      <iframe
        src="/catalog.html"
        title="Powerus systems catalog"
        style={{ width: '100%', height: '100%', border: 'none', display: 'block' }}
      />
    </main>
  );
}
